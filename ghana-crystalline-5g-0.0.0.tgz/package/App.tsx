import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { NetworkVisualizer } from './components/NetworkVisualizer';
import { MetricsDashboard } from './components/MetricsDashboard';
import { ConsciousnessInterface } from './components/ConsciousnessInterface';
import { LayoutDashboard, Activity, MessageSquare } from 'lucide-react';

enum ActiveView {
  DASHBOARD = 'DASHBOARD',
  VISUALIZER = 'VISUALIZER',
  INTERFACE = 'INTERFACE'
}

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<ActiveView>(ActiveView.DASHBOARD);
  const [isPresentationMode, setIsPresentationMode] = useState(false);

  const handleViewChange = (view: ActiveView) => {
    setActiveView(view);
    // Stop auto-cycle if user manually clicks
    if (isPresentationMode) {
      setIsPresentationMode(false);
    }
  };

  const togglePresentationMode = useCallback(() => {
    setIsPresentationMode(prev => !prev);
  }, []);

  // Auto-cycle logic for presentation mode
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    
    if (isPresentationMode) {
      interval = setInterval(() => {
        setActiveView(current => {
          if (current === ActiveView.DASHBOARD) return ActiveView.VISUALIZER;
          if (current === ActiveView.VISUALIZER) return ActiveView.INTERFACE;
          return ActiveView.DASHBOARD;
        });
      }, 8000); // Cycle every 8 seconds
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPresentationMode]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Space to toggle presentation mode
      if (e.code === 'Space' && e.target === document.body) {
        e.preventDefault();
        togglePresentationMode();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePresentationMode]);

  const renderContent = () => {
    switch (activeView) {
      case ActiveView.DASHBOARD:
        return <MetricsDashboard />;
      case ActiveView.VISUALIZER:
        return <NetworkVisualizer />;
      case ActiveView.INTERFACE:
        return <ConsciousnessInterface />;
      default:
        return <MetricsDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-[#050510] to-black text-white selection:bg-cyan-500 selection:text-black flex flex-col">
      <Header 
        isPresentationMode={isPresentationMode} 
        togglePresentationMode={togglePresentationMode} 
      />
      
      <main className="container mx-auto px-4 py-6 pb-20 flex-1">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
          
          {/* Sidebar Navigation */}
          <nav className="lg:col-span-2 glass-panel rounded-2xl p-4 h-fit sticky top-24 flex flex-row lg:flex-col justify-around lg:justify-start gap-4 z-40">
            <button
              onClick={() => handleViewChange(ActiveView.DASHBOARD)}
              className={`flex items-center gap-3 p-3 rounded-xl transition-all duration-300 ${
                activeView === ActiveView.DASHBOARD 
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.3)]' 
                  : 'hover:bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              <LayoutDashboard size={20} />
              <span className="hidden sm:inline font-semibold tracking-wide">Overview</span>
            </button>

            <button
              onClick={() => handleViewChange(ActiveView.VISUALIZER)}
              className={`flex items-center gap-3 p-3 rounded-xl transition-all duration-300 ${
                activeView === ActiveView.VISUALIZER
                  ? 'bg-purple-500/20 text-purple-400 border border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.3)]' 
                  : 'hover:bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              <Activity size={20} />
              <span className="hidden sm:inline font-semibold tracking-wide">Network Grid</span>
            </button>

            <button
              onClick={() => handleViewChange(ActiveView.INTERFACE)}
              className={`flex items-center gap-3 p-3 rounded-xl transition-all duration-300 ${
                activeView === ActiveView.INTERFACE
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.3)]' 
                  : 'hover:bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              <MessageSquare size={20} />
              <span className="hidden sm:inline font-semibold tracking-wide">Meta-Isi AI</span>
            </button>
          </nav>

          {/* Main Content Area */}
          <div className="lg:col-span-10 min-h-[600px]">
            {renderContent()}
          </div>

        </div>
      </main>

      <footer className="fixed bottom-0 w-full bg-black/80 backdrop-blur-md border-t border-white/10 py-2 px-4 flex justify-between items-center text-xs text-slate-500 z-50">
        <span>GHANA CRYSTALLINE NETWORK v5.0.2-Alpha // PROTOTYPE STATUS: ACTIVE</span>
        {isPresentationMode && (
          <span className="text-cyan-400 animate-pulse font-bold tracking-wider">PRESENTATION MODE ACTIVE (AUTO-CYCLE)</span>
        )}
      </footer>
    </div>
  );
};

export default App;