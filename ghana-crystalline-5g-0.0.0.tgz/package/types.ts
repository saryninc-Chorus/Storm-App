export interface MetricData {
  name: string;
  value: number | string;
  unit: string;
  status: 'optimal' | 'warning' | 'critical' | 'active';
  trend?: 'up' | 'down' | 'stable';
  description: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum NetworkStatus {
  ONLINE = 'ONLINE',
  HARMONIZING = 'HARMONIZING',
  OFFLINE = 'OFFLINE'
}
